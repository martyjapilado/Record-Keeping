h60570
s 00060/00000/00000
d D 1.1 18/10/25 20:49:35 mjka 1 0
c date and time created 18/10/25 20:49:35 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 24, 2018
//
//  FILE:        getaddress.g
//
//  DESCRIPTION:
//   This file contains the getaddress function, which is where the user is able
//   to record and input their address, especially on multiple lines
//
****************************************************************/

#include <stdio.h>
#include <string.h>
#include "getaddress.h"

/***************************************************
//
//   Function name: getaddress
//   
//   Description: A function that takes two parameters, a character array and an integer. 
//                The user enters an address which can be placed in multiple lines if they wish (to a max of 3 so far)
//                The 
//                
//   Parameters:    address: a character array which is actually a pointer, where we store the array based
//                           on user input
//                  lines: I can't ask the user for the amount of lines, but I can sure tell myself when it has to stop
//
//   Return values:   there is none
//
**************************************************/

void getaddress (char address[], int lines)
{
    int i;
    char userinput[80];
    for(i = 0; i < lines; i++)
    {
        printf("Address(%i/3):>>>", i + 1);
        fgets(userinput, 80, stdin);
        if (i >= 1) 
        {
            strcpy(address, strcat(address,userinput));
        } 
        else
        {
            strcpy(address, userinput);
        }
    }
    strcpy(address,strcat(address,"\0"));
}

E 1
