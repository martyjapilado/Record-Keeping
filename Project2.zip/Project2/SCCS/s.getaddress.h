h62293
s 00008/00003/00019
d D 1.2 18/11/25 23:03:15 mjka 2 1
c New getaddress.h for Project2
e
s 00022/00000/00000
d D 1.1 18/10/25 20:49:26 mjka 1 0
c date and time created 18/10/25 20:49:26 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
D 2
//  DATE:        October 24, 2018
E 2
I 2
//  DATE:        November 24, 2018
E 2
//
//  FILE:        getaddress.h
//
//  DESCRIPTION:
//   This file contains the prototype for the getaddress.h which is then written
D 2
//   in getaddress.c
E 2
I 2
//   in getaddress.cpp
E 2
//
****************************************************************/
I 2
#ifndef GETADDRESS_H
#define GETADDRESS_H
#include <string>
E 2

D 2
void getaddress (char address[], int input);
E 2
I 2
using namespace std;
void getaddress(string &, int);
#endif
E 2

E 1
