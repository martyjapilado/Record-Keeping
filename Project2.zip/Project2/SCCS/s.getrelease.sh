h13576
s 00010/00008/00000
d D 1.4 18/11/25 23:15:49 mjka 4 3
c New
e
s 00004/00004/00004
d D 1.3 18/11/25 22:58:12 mjka 3 2
c New New getrelease.sh
e
s 00007/00005/00001
d D 1.2 18/11/25 22:57:02 mjka 2 1
c new project2 getrelease
e
s 00006/00000/00000
d D 1.1 18/10/25 21:02:37 mjka 1 0
c date and time created 18/10/25 21:02:37 by mjka
e
u
U
f e 0
t
T
I 1
D 2
sccs get menu.c
sccs get recordfunctions.c
sccs get getaddress.c
sccs get iofunctions.c
E 2
I 2
D 4
sccs get llist.h
sccs get llist.cpp
sccs get menu.cpp
sccs get getaddress.cpp
D 3
sccs get records.h
sccs get getaddress.h
E 2
sccs get makefile
D 2
sccs get getrelease
E 1
E 2
I 2
sccs get getrelease.sh
E 2
E 3
I 3
sccs get records.h 1.2
sccs get getaddress.h 1.2
sccs get makefile 1.2
sccs get getrelease.sh 1.3
E 3
E 4
I 4
sccs get menu.c
sccs get recordfunctions.c
sccs get getaddress.c
sccs get iofunctions.c
sccs get -r1.1 records.h 
sccs get recordfunctions.h 
sccs get -r1.1 getaddress.h 
sccs get iofunctions.h
sccs get -r1.1 makefile 
sccs get -r1.1 getrelease 
E 4
