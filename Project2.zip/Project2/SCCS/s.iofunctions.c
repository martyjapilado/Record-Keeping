h50634
s 00122/00000/00000
d D 1.1 18/10/25 20:50:09 mjka 1 0
c date and time created 18/10/25 20:50:09 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    5
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 24, 2018
//
//  FILE:        iofunctions.c
//
//  DESCRIPTION:
//   This file contains the read and write functions used in the menu's main function to save data
//   in case the next use comes upon the program.
//
****************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "records.h"
#include "iofunctions.h"
#include "recordfunctions.h"

/***************************************************
//
//   Function name: readfile 
//   
//   Description: This is a function which takes data from 
//                a file and places a record baed off of that file from record
//                
//   Parameters:    accarray: This is a array of records that we copy data onto
//                  numcust: The latest position of the array we copy the data to
//                  filename: Name of the file name the function read froms
//
//   Return values:   0: to mark a successful call of the function
//                    -1: error conditon where the file we are given is actually empty
//
**************************************************/

int readfile(struct record ** start, char filename[ ] )
{
    char buffer[100];
    int uaccountno;
    char uname[25];
    char uaddress[80];
    FILE *file; 
    int retval;
    file = fopen(filename, "r");
    if (file == NULL)
    {
        retval = -1;
    }
    else 
    {
        while(feof(file) == 0) 
        {
            fgets(buffer, 20, file);
            uaccountno = atoi(buffer);
            fgets(uname, 25, file);
            fgets(buffer, 80, file);
            strcpy(uaddress, buffer);
			fgets(buffer, 80, file);
			strcat(uaddress, buffer);
            fgets(buffer, 80, file);
			strcat(uaddress, buffer);
			if (feof(file) == 0)
			{
			    addRecord(start, uaccountno, uname, uaddress);
			}
        }
        retval = 0;
        fclose(file);
    }

    return retval;
}

/***************************************************
//
//   Function name: writefile  
//   
//   Description: This is a function which takes data from 
//                a file and places a record baed off of that file from record
//                
//   Parameters:    accarray: This is a array of records that we copy data from
//                  numcust: The specifierd position of the array we copy the data from to write to
//                  filename: Name of the file name the function writes data to
//
//   Return values:   0: to mark a successful call of the function
//                    -1: error conditon where the specified data we are given is actually empty
//
**************************************************/

int writefile (struct record *start, char filename[ ])
{
    struct record *rec;
    FILE *file;
    int retval;
    if(start == NULL)
    {
        retval = -1;
    }
    else
    {
        file = fopen(filename,"w");
        rec = start;
        while(rec != NULL)
       {
            fprintf(file, "%i \n", rec->accountno);
            fprintf(file, "%s", rec->name);
            fprintf(file, "%s", rec->address);
            rec = rec->next;
        }
        fclose(file);
        retval = 0;
    }
    return retval;
}
E 1
