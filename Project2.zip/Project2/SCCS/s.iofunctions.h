h40346
s 00022/00000/00000
d D 1.1 18/10/25 20:50:06 mjka 1 0
c date and time created 18/10/25 20:50:06 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 23, 2018
//
//  FILE:        iofunctions.h
//
//  DESCRIPTION:
//   This file contains the function prototypes for iofunctions.c
//
****************************************************************/

int readfile(struct record **, char []);
int writefile(struct record *, char []);

E 1
