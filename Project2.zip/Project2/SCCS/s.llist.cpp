h15634
s 00532/00000/00000
d D 1.1 18/11/25 23:47:18 mjka 1 0
c date and time created 18/11/25 23:47:18 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:       November 17, 2018
//
//  FILE:        recordfunctions.cpp
//
//  DESCRIPTION:
//   This file contains the the collective function definitions
//   that manipulates records based on user input.
//
****************************************************************/

#include <string.h>
#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include "records.h"
#include "llist.h"

/***************************************************
//
//   Function name: llist
//
//   Description: A constructor that is used to initialize the llist
//
//   Parameters:   none
//
//   Return values:   there is none
//
**************************************************/

llist :: llist()
{
	start = NULL;
    strcpy(filename, "proj2.txt");
    readfile();
}

/***************************************************
//
//   Function name: llist
//
//   Description: A constructor that is used to initialize a copy of the llist
//
//   Parameters:   none
//
//   Return values:   there is none
//
**************************************************/

llist::llist(llist &list)
{
    record *current;
    current = list.start;
    while (current != NULL)
    {
        this->addRecord(current->accountno,current->name,current->address);
        current = current->next;
    }
}

/***************************************************
//
//   Function name: llist
//
//   Description: A constructor that is used to initialize the llist another way
//
//   Parameters:   none
//
//   Return values:   there is none
//
**************************************************/

llist::llist(char name[])
{
    this->start = NULL;
    strcpy(filename, name);
    if (readfile() == -1)
    {
        this->start = NULL;
    }
}
/***************************************************
//
//   Function name: ~llist
//
//   Description: A deconstructor that is used to get rid of that list
//
//   Parameters:   none
//
//   Return values:   there is none
//
**************************************************/

llist:: ~llist()
{

    writefile();
    cleanup();
    
}

/***************************************************
//
//   Function name: addRecord
//
//   Description: A function that takes in all parameters inputted by the user and places it into a record, placed into the database
//
//   Parameters:   uaccountno: The account number that is inputed by the user.
//                 uname: The name that was inputted by the user.
//                 uaddress: a character array which is an address inputted by the user.
//
//   Return values:   there is none
//
**************************************************/

int llist :: addRecord(int uaccountno, char uname[], char  uaddress[])
{
    using namespace std;
    struct record *temp1;
    struct record *temp2;
    struct record *checknext;

    temp1 = new record;

    if ((this->start) == NULL)
    {
        temp1->accountno = uaccountno;
        strcpy(temp1->name, uname);
        strcpy(temp1->address, uaddress);
        temp1->next = NULL;
        this->start = temp1;
    }
    else if (uaccountno <= (this->start)->accountno)
    {
        temp2 = (this->start); 
        temp1->accountno = uaccountno;
        strcpy(temp1->name, uname);
        strcpy(temp1->address, uaddress);
        temp1->next = temp2;
        this->start = temp1;
    }
    else
    {
        temp2 = (this->start);
        temp1->accountno = uaccountno;
        strcpy(temp1->name, uname);
        strcpy(temp1->address, uaddress);
        checknext = temp2->next;
        
        while (checknext != NULL && uaccountno > checknext->accountno)
        {
            temp2 = temp2->next;
            checknext = temp2->next;
        }
        temp1->next = checknext;
        temp2->next = temp1;
    }
    return 0;
}

/***************************************************
//
//   Function name: deleteRecord
//
//   Description: A function that takes away record from database based off of accountno
//
//   Parameters:   start: The address in memory to mark the start of the list of records
//                 uaccountno: The designated account number of soon-to-be deleted file that is inputed by the user.
//
//   Return values: -1:if nothing is deleted
//                  0: if designated record(s) are deleted
//
**************************************************/

int llist :: deleteRecord(int uaccountno)
{
    using namespace std;
    struct record *current;
    struct record *prev;
    struct record *samenopoint;
    struct record *holdcurrent;
    int retval;
    if (this->start == NULL)
    {
        retval = -1;
    }
    else if ((this->start)->accountno == uaccountno)
    {
        current = this->start;
        while (current != NULL && current->accountno == uaccountno)
        { 
            holdcurrent = current;
            this->start = holdcurrent->next;
            delete current;
            current = this->start;
        }
        retval = 0;
    }
    else
    {
        current = this->start;
        samenopoint = current;
        while (current != NULL && current->next != NULL && current->accountno != uaccountno)
        {
            current = current->next;
            samenopoint = samenopoint->next;
        }
        while (samenopoint != NULL && samenopoint->next != NULL &&  uaccountno == samenopoint->accountno)
        {
            samenopoint = samenopoint->next;
        }
        prev = this->start;
        while (prev != current && prev->next != current)
        {
            prev = prev->next;
        }
        if (samenopoint != NULL && samenopoint->accountno == uaccountno)
        {
            while (current != samenopoint && current->accountno == uaccountno)
            {
                holdcurrent = current->next;
                delete current;
                current = holdcurrent;
            }
            delete current;
            prev->next = NULL;
            retval = 0;
        }
        else if (current->accountno != uaccountno)
        {
            retval = -1;
        }
        else
        {
            while (current != samenopoint)
            {
                holdcurrent = current->next;
                delete current;
                current = holdcurrent;
            }
            prev->next = samenopoint;
            retval = 0;
        }
    }

    return retval;
}

/***************************************************
//
//   Function name: printRecord
//
//   Description: A function that takes in an account no. inputted by the user to print the specified records.
//
//   Parameters:   start: The address in memory to mark the start of the list of records
//                 uaccountno: The account number that is inputed by the user.
//
//   Return values:   -1: if nothing is printed
//                    0: if designated record(s) are printed
//
**************************************************/

int llist :: printRecord(int uaccountno)
{
    using namespace std;
    struct record *current;
    struct record *samenopoint;
    struct record *holdcurrent;
    int retval;
    if (start == NULL)
    {
        retval = -1;
    }
    else if (start->accountno == uaccountno)
    {
        current = start;
        while (current->accountno == uaccountno && current->next != NULL)
        {
            current = current->next;
            cout << current->accountno << endl;
            cout << current->name << endl;
            cout << current->address << endl;
        }
        retval = 0;
    }
    else
    {
        current = start;
        samenopoint = current;
        while (current != NULL && current->next != NULL && current->accountno != uaccountno)
        {
            current = current->next;
            samenopoint = current->next;
        }
        while (samenopoint != NULL && samenopoint->next != NULL && uaccountno == samenopoint->accountno)
        {
            samenopoint = samenopoint->next;
        }
        if (samenopoint != NULL && samenopoint->accountno == uaccountno)
        {
            while (current != samenopoint && current->accountno == uaccountno)
            {
                holdcurrent = current->next;
                cout << current->accountno << endl;
                cout << current->name << endl;
                cout << current->address << endl;
                current = holdcurrent;
            }
            cout << samenopoint->accountno << endl;
            cout << samenopoint->name << endl;
            cout << samenopoint->address << endl;
            retval = 0;
        }
        else if (current->accountno != uaccountno)
        {
            retval = -1;
        }
        else
        { 
            while (current != samenopoint)
            {
                holdcurrent = current->next;
                cout << current->accountno << endl;
                cout << current->name << endl;
                cout << current->address << endl;
                current = holdcurrent;
            }
            retval = 0;
        }
    }
    return retval;
}

/***************************************************
//
//   Function name: <<
//
//   Description: A function that simply prints all of the functions.
//
//   Parameters:   start: The address in memory to mark the start of the list of records
//
//   Return values:   there is none
//
**************************************************/


std::ostream& operator<<(std::ostream& os , llist & list)
{
    using namespace std;
    record * current;
    current = list.start;
    if (current == NULL)
    {
        cout << "There is nothing in the list\n";
    }
    else
    {
        while (current != NULL)
        {
            cout << current->accountno << '\n';
            cout << current->name << endl;
            cout << current->address << endl; 
            cout << endl;
            current = current->next;
        }

    }
	
    return os;
}

/***************************************************
//
//   Function name: readfile
//
//   Description: This is a function which takes data from
//                a file and places a record baed off of that file from record
//
//   Parameters:    accarray: This is a array of records that we copy data onto
//                  numcust: The latest position of the array we copy the data to
//                  filename: Name of the file name the function read froms
//
//   Return values:   0: to mark a successful call of the function
//                    -1: error conditon where the file we are given is actually empty
//
**************************************************/

int llist::readfile()
{
    using namespace std;
    char buffer[100];
    int uaccountno;
    char uname[25];
    char uaddress[80];
    ifstream file(this->filename);
    int retval;
    if (file.is_open())
    {
        while (!file.eof())
        {
            file.getline(buffer,100, '\n');
            uaccountno = atoi(buffer);
            file.getline(uname, 100, '\n');
                 file.getline(buffer, 100, '!');
                 strcpy(uaddress,buffer);
                 file.getline(buffer, 100, '\n');
            if (!file.eof())
            {
                addRecord(uaccountno, uname, uaddress);
            }
            else
            {
                file.close();
            }
        }
        retval = 0;
        
    }
    else
    {
        retval = -1;
    }
    return retval;
}

void llist :: cleanup()
{
    while (this->start != NULL)
    {		

        deleteRecord(this->start->accountno);
    }
}

/***************************************************
//
//   Function name: writefile
//
//   Description: This is a function which takes data from
//                a file and places a record baed off of that file from record
//
//   Parameters:    accarray: This is a array of records that we copy data from
//                  numcust: T		he specifierd position of the array we copy the data from to write to
//                  filename: Name of the file name the function writes data to
//
//   Return values:   0: to mark a successful call of the function
//                    -1: error conditon where the specified data we are given is actually empty
//
**************************************************/

void llist :: writefile()
{
    using namespace std;
    struct record *rec;
    ofstream file;
    file.open(this->filename,ios::out| ios::trunc);
    rec = this->start;
    while (rec != NULL && rec != NULL)
    {
        file << rec->accountno << endl;
        file << rec->name << endl;
        file << rec->address;
        file << '!' << endl;
        rec = rec->next;
    }
    file.close();
#ifdef DEBUG
	
#endif // DEBUG

}

/***************************************************
//
//   Function name: reverse 
//
//   Description: This is a function which takes data from
//                a start and reverses the list
//
//   Parameters:    recstart: takes in start at the void function
//
//   Return values:  this->start: returns start with a reversed function.
//
**************************************************/

record * llist::reverse(record *start)
{
    using namespace std;
    record *temp;
    if (start == NULL)
    {
		temp = NULL;
    }
    else if (start->next == NULL)
    {
        temp = start;
    }
	else
	{
		temp = reverse(start->next);
		start->next->next = start;
		start->next = NULL;
	}
	return temp;
}

/***************************************************
//
//   Function name: reverse
//
//   Description: Finishes the other reverse job
//
//   Parameters:    none
//
//   Return values:  none
//
**************************************************/

void llist::reverse()
{
    start = reverse(start);
}
E 1
