h07521
s 00045/00000/00000
d D 1.1 18/11/25 20:44:37 mjka 1 0
c date and time created 18/11/25 20:44:37 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 24, 2018
//
//  FILE:        llist.h
//
//  DESCRIPTION:
//   This file contains the class of llist.cpp so we can make a list of records
//   to operate on
//
****************************************************************/

#ifndef LLIST_H
#define LLIST_H

class llist
{
private:
    record *    start;
    char        filename[16];
    int         readfile();
    void        writefile();
    record *    reverse(record *);
    void        cleanup();
public:

    llist();
    llist(char[]);
    llist(llist &llist);
    ~llist();
    int addRecord(int, char[], char[]);
    int printRecord(int);
    friend std::ostream& operator<<(std::ostream& os, llist &list);
    int deleteRecord(int);
    void reverse();
};
#endif
E 1
