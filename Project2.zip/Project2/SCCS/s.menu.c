h55596
s 00182/00000/00000
d D 1.1 18/10/25 20:50:36 mjka 1 0
c date and time created 18/10/25 20:50:36 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        Octuober 24, 2018
//
//  FILE:        menu.c
//
//  DESCRIPTION:
//   This file contains the menu interface that the user inserts the records into. A file is saved and read based on previous input.
//
****************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "records.h"
#include "getaddress.h"
#include "recordfunctions.h"	
#include "iofunctions.h"

/***************************************************
//
//   Function name: main
//   
//   Description: A user interface function that takes allows user interaction and input and the input 
//                determines the process of the outward program. 
//                So far I have a:
//                An exit function to exit the program.
//                
//   Parameters:    None that I know of so far
//
//   Return values:   there is none
//
**************************************************/

int debug = 0;

int main(int argc, char *argv[])
{
    int control; 
    int uaccountno;
    char uname[25];
    char uaddress[80];
    char input[25];
    struct record *start;
    int deletconfirm;
    start = NULL;
    control = 1;
    if (argc == 2 && strcmp(argv[1], "debug") == 0  )
    {
        debug = 1;
    }
    else if(argc >= 2 && strcmp(argv[1], "debug") != 0)
    {
        printf("error: unsure what %s is", argv[1]);
        control = 0;
    }
    else
    {
        debug = 0;
    }
    
    readfile(&start, "database.txt");
    if(debug == 1)
    {
    printf("**DEBUG** Function Name: readfile \n");
    printf("**DEBUG** Parameters: \n");
    printf("**DEBUG** filename = \"database.txt\" \n");
    }

    while(control != 0)
    {

        printf("What would you like to do?\n");
        printf("add - Add a new record to database\n");
        printf("print - Print information about a record\n");
        printf("printall - Print all information in database\n");
        printf("delete- Delete an existing record(s)\n");
        printf("exit - Quit from program\n");
        fgets(input, 25 ,stdin);
        if (strcmp(input,"exit\n") == 0)
        {
            control = 0;        
        }
        else if (strcmp(input,"add\n") == 0)
        {
            printf("Account No.:>>>");
            fgets(input, 25 ,stdin);
            uaccountno = atoi(input);
            printf("Name:>>>");
            fgets(uname, 25 ,stdin);
            getaddress(uaddress,3);
            if (debug == 1) 
            {
                printf("\n**DEBUG** Function Name: getaddress \n");
                printf("**DEBUG** Parameters: \n");
                printf("**DEBUG** uaddress = %s, lines = 3 \n", uaddress);
            }
            addRecord(&start, uaccountno, uname, uaddress);
            printf("The record has been added \n");
            if (debug == 1) 
            {
                printf("\n**DEBUG** Function Name: addRecord \n");
                printf("**DEBUG** Parameters: \n");
                printf("**DEBUG** uaccountno = %i, uname = %s, uaddress = %s \n", uaccountno, uname, uaddress);
            }
        }
        else if (strcmp(input,"print\n") == 0)
        {
            printf("Designate Account No to print.:>>>");
            fgets(input, 25 ,stdin);
            uaccountno = atoi(input);
            printRecord(start, uaccountno);
            if (debug == 1) 
            {
                printf("\n**DEBUG** Function Name: printRecord \n");
                printf("**DEBUG** Parameters: \n");
                printf("**DEBUG** uaccountno = %i\n", uaccountno);
            }
        }
        else if (strcmp(input," \n") == 0)
        {
            printAllRecords(start);
            if (debug == 1) 
            {
                printf("\n**DEBUG** Function Name: printAllRecords \n");
                printf("**DEBUG** Parameters: \n");
                printf("**DEBUG** address in start \n");
            }
        }
        else if (strcmp(input,"printall\n") == 0)
        {
            printAllRecords(start);
            if (debug == 1) 
            {
                printf("\n**DEBUG** Function Name: printAllRecords \n");
                printf("**DEBUG** Parameters: \n");
                printf("**DEBUG** address in start\n");
            }
        }
        else if (strcmp(input,"delete\n") == 0)
        {
            printf("Designate Account No. for deletion:>>>");
            fgets(input, 25 ,stdin);
            uaccountno = atoi(input);
			deletconfirm = deleteRecord(&start, uaccountno);  
            if( deletconfirm == 0) {
                printf("The record has been deleted \n");
            }
            else 
            {
                printf("The record did not exist\n");
            }
            if (debug == 1) 
            {
                printf("\n**DEBUG** Function Name: deleteRecord \n");
                printf("**DEBUG** Parameters: \n");
                printf("**DEBUG** uaccountno = %i", uaccountno);
            }
        } 
        else 
        {
            printf("error: Invalid input\n");
        }
    }
    writefile(start, "database.txt");

    if (debug == 1)
    {
    printf("\n**DEBUG** Function Name: writefile \n");
    printf("**DEBUG** Parameters: \n");
    printf("**DEBUG** address in start, filename = \"database.txt\" \n");
    }
    return 0;
}
E 1
