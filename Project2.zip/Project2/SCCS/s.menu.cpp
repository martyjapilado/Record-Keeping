h13254
s 00165/00000/00000
d D 1.1 18/11/25 20:44:48 mjka 1 0
c date and time created 18/11/25 20:44:48 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        November 17, 2018
//
//  FILE:        menu.cpp
//
//  DESCRIPTION:
//   This file contains the menu interface that the user inserts the records into. A file is saved and read based on previous input.
//
****************************************************************/

#include <stdlib.h>
#include <iostream>
#include <string>
#include <string.h>
#include "records.h"
#include "getaddress.h"
#include "llist.h"	


/***************************************************
//
//   Function name: main
//
//   Description: A user interface function that takes allows user interaction and input and the input
//                determines the process of the outward program.
//                So far I have a:
//                An exit function to exit the program.
//
//   Parameters:    None that I know of so far
//
//   Return values:   there is none
//
**************************************************/



int main()
{
    using namespace std;
    llist database;
    llist copydata(database);
    string userinput;
    int control;
    int uaccountno;
    char uname[25];
    string straddress;
    char uaddress[80];
    char input[200];
    int deleteconfirm;
    control = 1;

    #ifdef DEBUG
        cout << "\n**DEBUG** Function Name: writefile \n";
    #endif // DEBUG

    while (control != 0)
    {

        cout << "\nWhat would you like to do?\n";
        cout << "add - Add a new record to database\n";
        cout << "print - Print information about a record\n";
        cout << "printall - Print all information in database\n";
        cout << "delete - Delete an existing record(s)\n";
        cout << "reverse - reverse the list\n";
        cout << "exit - Quit from program\n";
        cin >> input;
        if (strcmp(input, "exit") == 0)
        {
            control = 0;
        }
        else if (strcmp(input, "add") == 0)
        {
            cout << "Account No.:>>>";
            cin >> input;
            uaccountno = atoi(input);

            cout << "Name:>>>";
            cin.ignore();
            getline(cin, userinput, '\n');
            strcpy(uname, userinput.c_str());
            getaddress(straddress, 80);
            strcpy(uaddress,straddress.c_str());
            database.addRecord(uaccountno, uname, uaddress);
        #ifdef DEBUG
            cout << "\n**DEBUG** Function Name: getaddress \n";
            cout << "**DEBUG** Parameters: \n";
            cout << "**DEBUG** uaddress = " << uaddress << "limit = 80\n";
        #endif

            cout << "The record has been added" << endl;
            straddress = "";
        #ifdef DEBUG 
            cout << "\n**DEBUG** Function Name: addRecord \n";
            cout << "**DEBUG** Parameters: \n";
            cout << "**DEBUG**	 uaccountno = " << uaccountno << ", uname  = ," << uname << ", uaddress =" << uaddress;
        #endif
        }
        else if (strcmp(input, "print") == 0)
        {
            cout << "Designate Account No to print.:>>>";
            cin >> input;
            uaccountno = atoi(input);
            if (database.printRecord(uaccountno) != 0)
            {
                cout << "Record does not exist";
            }
            #ifdef DEBUG
                cout << "\n**DEBUG** Function Name: printRecord \n";
                cout << "**DEBUG** Parameters: \n";
                cout << "**DEBUG** uaccountno = " << uaccountno;
            #endif 
        }
        else if (strcmp(input, "printall") == 0)
        {
            cout << database;
        }
        else if (strcmp(input, "delete") == 0)
        {
            cout << "Designate Account No. for deletion:>>>";
            cin >> input;
            uaccountno = atoi(input);
            deleteconfirm = database.deleteRecord(uaccountno);
            if (deleteconfirm == 0) 
            {
                cout << "\nThe record has been deleted \n" << "\n";
            }
            else
            {
                cout << "\nThe record did not exist\n" << "\n";
            }
        #ifdef DEBUG
            cout << "\n**DEBUG** Function Name: deleteRecord \n";
            cout << "**DEBUG** Parameters: \n";
            cout << "**DEBUG** uaccountno = " << uaccountno;
        #endif // DEBUG
        }
        else if (strcmp(input, "reverse") == 0)
        {
            database.reverse();
            #ifdef DEBUG
                cout << "\n**DEBUG** Function Name: writefile \n";
            #endif // DEBUG
        }
        else
        {
            cout << "\n"  << "error: Invalid input\n" << endl;
        }
    }

    #ifdef DEBUG
        cout << "\n**DEBUG** Function Name: writefile \n";
    #endif // DEBUG

     return 0;
}

E 1
