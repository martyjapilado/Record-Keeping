h09738
s 00290/00000/00000
d D 1.1 18/10/25 20:50:14 mjka 1 0
c date and time created 18/10/25 20:50:14 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 24, 2018
//
//  FILE:        recordfunctions.c
//
//  DESCRIPTION:
//   This file contains the the collective function definitions
//   that manipulates records based on user input.
//
****************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "records.h"

/***************************************************
//
//   Function name: addRecord
//   
//   Description: A function that takes in all parameters inputted by the user and places it into a record, placed into the database
//
//   Parameters:   start: The address in memory to mark the start of the list of records 
//                 uaccountno: The account number that is inputed by the user.
//                 uname: The name that was inputted by the user.
//                 uaddress: a character array which is an address inputted by the user.
//                 
//   Return values:   there is none
//
**************************************************/

void addRecord (struct record ** start, int uaccountno, char uname[ ]  ,char  uaddress[ ])
{

    struct record *temp1;
    struct record *temp2;
	struct record *checknext;
    temp1 = (struct record*) malloc (sizeof (struct record));

    if ( (*start) == NULL )
    {
        temp1->accountno = uaccountno;
        strcpy(temp1->name, uname);
        strcpy(temp1->address, uaddress);
        temp1->next = NULL;
        *start = temp1;
    }
    else if ( uaccountno <= (*start)->accountno )
    {
        temp2 = (*start);
        temp1->accountno = uaccountno;
        strcpy(temp1->name, uname);
        strcpy(temp1->address, uaddress);
        temp1->next = temp2;
        *start = temp1;
    }
    else
    {		
        temp2 = (*start);
        temp1->accountno = uaccountno;
        strcpy(temp1->name, uname);
        strcpy(temp1->address, uaddress);
        checknext = temp2->next;
    
        while (temp2->next != NULL && uaccountno > checknext->accountno) 
        {
            temp2 = temp2->next;
			checknext = checknext->next;
        }   
        temp1->next = checknext;
        temp2->next = temp1;
    }
}

/***************************************************
//
//   Function name: deleteRecord
//   
//   Description: A function that takes away record from database based off of accountno
//
//   Parameters:   start: The address in memory to mark the start of the list of records 
//                 uaccountno: The designated account number of soon-to-be deleted file that is inputed by the user.
//                 
//   Return values: -1:if nothing is deleted
//                  0: if designated record(s) are deleted
//
**************************************************/

int deleteRecord(struct record ** start, int uaccountno)
{
    struct record *current;
    struct record *prev;
    struct record *samenopoint;
    struct record *holdcurrent;
    int retval;
    if (*start == NULL)
    {
        retval = -1;
    }
    else if ((*start)->accountno == uaccountno)
    {
        current = *start;
        while (current != NULL && current->accountno == uaccountno )
        {
            *start = current->next;
            free(current);
			current = *start;
        }
        retval = 0;
    }
    else
    {
        current = *start;
        samenopoint = current;
        while ( current->next != NULL && current->accountno != uaccountno)
        {
            current = current->next;
            samenopoint = samenopoint->next;
        }
        while ( samenopoint->next != NULL && uaccountno == samenopoint->accountno)
        {
            samenopoint = samenopoint->next;
        }
        prev = *start;
        while ( prev != current && prev->next != current )
        {
            prev = prev->next;
        }
        if (samenopoint != NULL && samenopoint->accountno == uaccountno)
        {
            while ( current != samenopoint && current->accountno == uaccountno)
            {
                holdcurrent = current->next;
                free(current);
                current = holdcurrent;
            }
            free(samenopoint); 
            prev->next = NULL;
            retval = 0;
        }
        else if (current->accountno != uaccountno)
        {
            retval = -1;
        }
        else
        {
            while (current != samenopoint)
            {
                holdcurrent = current->next;
                free(current);
                current = holdcurrent;
            }
            prev->next = samenopoint;
            retval = 0;
        }
    }

    return retval;
}

/***************************************************
//
//   Function name: printRecord
//   
//   Description: A function that takes in an account no. inputted by the user to print the specified records.
//
//   Parameters:   start: The address in memory to mark the start of the list of records 
//                 uaccountno: The account number that is inputed by the user.
//                 
//   Return values:   -1: if nothing is printed
//                    0: if designated record(s) are printed
//
**************************************************/

int printRecord(struct record * start, int uaccountno)
{
    struct record *current;
    struct record *samenopoint;
    struct record *holdcurrent;
    int retval;
    if (start == NULL)
    {
        retval = -1;
    }
    else if (start->accountno == uaccountno )
    {
        current = start;
        printf("%i \n", current->accountno);
        printf("%s", current->name);
        printf("%s \n", current->address);
        while ( current->accountno == uaccountno && current->next != NULL)
        {
			current = current->next;
            printf("%i \n", current->accountno);
            printf("%s", current->name);
            printf("%s \n", current->address);
        }
        retval = 0;
    }
    else
    {
        current = start;   
		samenopoint = current;
        while ( current->next != NULL && current->accountno != uaccountno)
        {
            current = current->next;
			samenopoint = current->next;
        }
        while (samenopoint->next != NULL && uaccountno == samenopoint->accountno)
        {
            samenopoint = samenopoint->next;
        }
        if (samenopoint != NULL && samenopoint->accountno == uaccountno)
        {
            while ( current != samenopoint && current->accountno == uaccountno)
            {
                holdcurrent = current->next;
                printf("%i\n", current->accountno);
                printf("%s", current->name);
                printf("%s\n", current->address);
                current = holdcurrent;
            }
            printf("%i\n", samenopoint->accountno);
            printf("%s", samenopoint->name);
            printf("%s\n", samenopoint->address);
            retval = 0;
        }
        else if (current->accountno != uaccountno)
        {
            retval = -1;
        }
        else
        {
            while (current != samenopoint)	
            {
                holdcurrent = current->next;
                printf("%i\n", current->accountno);
                printf("%s", current->name);
                printf("%s\n", current->address);
                current = holdcurrent;
            }
            retval = 0;
        }
    }
    return retval;
}

/***************************************************
//
//   Function name: printAllRecords
//   
//   Description: A function that simply prints all of the functions.
//
//   Parameters:   start: The address in memory to mark the start of the list of records 
//                 
//   Return values:   there is none
//
**************************************************/

void printAllRecords(struct record * start)
{
    struct record *current;
    current = start;
    if (start == NULL)
    {
        printf("There is nothing in the list\n");
    }
	else
	{
		while (current != NULL)
		{
			printf("%i\n", current->accountno);
			printf("%s", current->name);
			printf("%s\n", current->address);
			current = current->next;
		}
	}
}
    


E 1
