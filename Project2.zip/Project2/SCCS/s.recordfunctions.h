h62022
s 00026/00000/00000
d D 1.1 18/10/25 20:50:22 mjka 1 0
c date and time created 18/10/25 20:50:22 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 24, 2018
//
//  FILE:        recordfunctions.h
//
//  DESCRIPTION:
//   This file contains the function prototypes for the collective functions
//   that manipulates records based on user input.
//
****************************************************************/

void addRecord (struct record **, int, char [ ],char [ ]);
int printRecord (struct record *, int);
void printAllRecords(struct record *);
int deleteRecord(struct record **, int);
int readfile(struct record **, char []);
int writefile(struct record *, char []);
E 1
