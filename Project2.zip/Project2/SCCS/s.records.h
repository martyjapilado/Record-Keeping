h64112
s 00005/00001/00026
d D 1.2 18/11/25 23:07:30 mjka 2 1
c New record for C++
e
s 00027/00000/00000
d D 1.1 18/10/25 20:50:26 mjka 1 0
c date and time created 18/10/25 20:50:26 by mjka
e
u
U
f e 0
t
T
I 1
/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
D 2
//  HOMEWORK:    Project1
E 2
I 2
//  HOMEWORK:    Project2
E 2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 24, 2018
//
//  FILE:        records.h
//
//  DESCRIPTION:
//   This file contains the structure "record", as directed in the project page.
//   Here, I placed the indicated structure, as well as the definition that is passed to database functions
//
****************************************************************/

I 2
#ifndef RECORDS_H
#define RECORDS_H

E 2
struct record
{
    int              accountno;
    char             name[25];
    char             address[80];
    struct record*   next;
};
E 1
I 2
#endif
E 2
