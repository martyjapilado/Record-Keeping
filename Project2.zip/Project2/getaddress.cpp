/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        November 17, 2018
//
//  FILE:        getaddress.cpp
//
//  DESCRIPTION:
//   This file contains the getaddress function, which is where the user is able
//   to record and input their address, especially on multiple lines
//
****************************************************************/

#include <iostream>
#include "getaddress.h"
#include <string>
#include <string.h>

/***************************************************
//
//   Function name: getaddress
//
//   Description: A function that takes two parameters, a character array and an integer.
//                The user enters an address which can be placed in multiple lines if they wish (to a max of 3 so far)
//                The
//
//   Parameters:    address: a character array which is actually a pointer, where we store the array based
//                           on user input
//                  lines: I can't ask the user for the amount of lines, but I can sure tell myself when it has to stop
//
//   Return values:   there is none
//
**************************************************/

void getaddress(string & address, int limit)
{
    using namespace std;
    int i;
    string userinput;
    int endaddress;
    i = 1;
    endaddress = 0;
    cout << "Place a '!' to end address input" << endl;
    while (endaddress == 0 && strlen(address.c_str()) <= 80)
    {
        cout << "Address(Line:" << i << "):>>>";
        getline(cin, userinput, '\n');
        if (strchr(userinput.c_str() ,'!') != 0)
        {
            endaddress = -1;
        }
        else if (i >= 1)
        {
            address = address + userinput;
            address += '\n';
            i++;
        }
        else
        {
            address = userinput;
            i++;
        }
    }
}
