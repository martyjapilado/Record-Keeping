/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project1
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        November 24, 2018
//
//  FILE:        getaddress.h
//
//  DESCRIPTION:
//   This file contains the prototype for the getaddress.h which is then written
//   in getaddress.cpp
//
****************************************************************/
#ifndef GETADDRESS_H
#define GETADDRESS_H
#include <string>

using namespace std;
void getaddress(string &, int);
#endif

