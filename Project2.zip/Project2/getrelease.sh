sccs get menu.c
sccs get recordfunctions.c
sccs get getaddress.c
sccs get iofunctions.c
sccs get -r1.1 records.h 
sccs get recordfunctions.h 
sccs get -r1.1 getaddress.h 
sccs get iofunctions.h
sccs get -r1.1 makefile 
sccs get -r1.1 getrelease 
