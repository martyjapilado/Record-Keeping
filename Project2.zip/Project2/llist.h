/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 24, 2018
//
//  FILE:        llist.h
//
//  DESCRIPTION:
//   This file contains the class of llist.cpp so we can make a list of records
//   to operate on
//
****************************************************************/

#ifndef LLIST_H
#define LLIST_H

class llist
{
private:
    record *    start;
    char        filename[16];
    int         readfile();
    void        writefile();
    record *    reverse(record *);
    void        cleanup();
public:

    llist();
    llist(char[]);
    llist(llist &llist);
    ~llist();
    int addRecord(int, char[], char[]);
    int printRecord(int);
    friend std::ostream& operator<<(std::ostream& os, llist &list);
    int deleteRecord(int);
    void reverse();
};
#endif
