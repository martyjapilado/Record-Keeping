/*****************************************************************
//
//  NAME:        Marty Joshua Apilado
//
//  HOMEWORK:    Project2
//
//  CLASS:       ICS 212
//
//  INSTRUCTOR:  Ravi Narayan
//
//  DATE:        October 24, 2018
//
//  FILE:        records.h
//
//  DESCRIPTION:
//   This file contains the structure "record", as directed in the project page.
//   Here, I placed the indicated structure, as well as the definition that is passed to database functions
//
****************************************************************/

#ifndef RECORDS_H
#define RECORDS_H

struct record
{
    int              accountno;
    char             name[25];
    char             address[80];
    struct record*   next;
};
#endif
